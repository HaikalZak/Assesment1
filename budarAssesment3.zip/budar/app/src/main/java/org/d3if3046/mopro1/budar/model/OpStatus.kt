package org.d3if3046.mopro1.budar.model

data class OpStatus(
    var status: String,
    var message:String?
)
