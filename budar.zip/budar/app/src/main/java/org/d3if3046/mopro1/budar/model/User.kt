package org.d3if3046.mopro1.budar.model

data class User(
    val name: String = "",
    val email: String = "",
    val photoUrl: String=""
)
