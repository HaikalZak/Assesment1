package org.d3if3046.mopro1.budar.model

data class Haikal(
    val id: String,
    val judul: String,
    val deskripsi: String,
    val image: String,
    val auth: String,
    val mine: Int
)
